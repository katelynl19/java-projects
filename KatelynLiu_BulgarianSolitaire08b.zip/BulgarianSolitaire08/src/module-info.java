/**
 * 
 */
/**
 * @author katelynliu
 *
 */
module BulgarianSolitaire08 {
}