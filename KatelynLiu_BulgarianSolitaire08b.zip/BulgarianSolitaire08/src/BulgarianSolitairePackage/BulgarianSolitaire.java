// Author: Katelyn Liu
// Date: 6/8/23
// Assignment: Bulgarian Solitaire
// Class: Java CIS 016


package BulgarianSolitairePackage;

import java.util.ArrayList;
import java.util.Random;
import java.util.Collections;

public class BulgarianSolitaire {
	private ArrayList<Integer> stacks;

    public BulgarianSolitaire() {
        stacks = new ArrayList<>();
    }

    public void makeRandomStacks() {
    	Random random = new Random();
        int totalCards = 45;
        int minStacks = 3;
        int maxStacks = 8;
        int remainingCards = totalCards;
        int sum = 0;

        int numStacks = random.nextInt(maxStacks - minStacks + 1) + minStacks; // choosing random number of stacks between 3 and 8

        for (int i = 0; i < (numStacks-1); i++) {
        	// distributing a random number of cards to each stack
            stacks.add(random.nextInt(remainingCards - (numStacks - i))+1);
            remainingCards = remainingCards - stacks.get(i);
        }
        stacks.add(remainingCards); // adding remaining cards to last stack
        
        for (int i = 0; i < stacks.size(); i++) {
        	// summing the number of cards
        	sum = sum + stacks.get(i);
        }
        
        // asserting that there are 45 cards
        assert(sum == 45) : "The number of cards is incorrect.";
    }

    public boolean isSortedAscending() {
    	
    	// checking whether the cards are sorted in ascending order in increments of one; this is to see if the game is over
    	if (stacks.size() != stacks.get(stacks.size()-1)) {
            return false;
        }

        for (int i = 0; i < stacks.size(); i++) {
            if (stacks.get(i) != i + 1) {
                return false;
            }
        }

        return true;
    }

    public void sortStacks() {
    	// sorting stacks in ascending order
        Collections.sort(stacks);
    }

    public void playRound() {
    	// executed for each round
        for (int i = 0; i < stacks.size(); i++) {
        	// taking one card from each stack
            stacks.set(i, stacks.get(i)-1);
        }
        
        stacks.add(stacks.size()); // making a new stack with the taken cards
        sortStacks();
        stacks.removeIf(stack -> stack == 0); // removing empty stacks
    }

    public void printStacks() {
    	
        for (int j = 0; j < stacks.size(); j++) {
        	// printing original stacks of cards
        	System.out.print(stacks.get(j)+ " ");
        }
        System.out.println("");
        System.out.println("----------");

        while (!isSortedAscending()) {
        	// while the cards aren't sorted from 1 2 3 4 5 6 7 8 9 yet, keep playing
            playRound();
            for (int i = 0; i < stacks.size(); i++) {
            	// printing the stack sizes
            	System.out.print(stacks.get(i) + " ");
            }
            System.out.println("");
        }
    }
}