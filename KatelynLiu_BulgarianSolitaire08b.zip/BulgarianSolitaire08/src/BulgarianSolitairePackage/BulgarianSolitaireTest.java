// Author: Katelyn Liu
// Date: 6/8/23
// Assignment: Bulgarian Solitaire
// Class: Java CIS 016

package BulgarianSolitairePackage;

public class BulgarianSolitaireTest {

	public static void main(String[] args) {
        BulgarianSolitaire game = new BulgarianSolitaire(); // creating new game object
        game.makeRandomStacks();
        game.printStacks();
	}

}
