// Author: Katelyn Liu
// Date: 7/25/23
// Assignment: Calculator 12
// Class: Java CIS 016

package myJavaFXpkg;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;


public class MyJavaFX extends Application 
{
	
	String firstNumber = "";
	String currNumber = "";
	String operator = "";
	double answer;
	double firstNumDouble;
	double secondNumDouble;
	
	// creating label to display numbers & answer
	Label myLabel = new Label("0");
	
	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) {
		//creating and formatting all of the buttons
		Button zero = new Button("0");
		zero.setMinWidth(100);
		zero.setMinHeight(50);
		Button one = new Button("1");
		one.setMinWidth(50);
		one.setMinHeight(50);
		Button two = new Button("2");
		two.setMinWidth(50);
		two.setMinHeight(50);
		Button three = new Button("3");
		three.setMinWidth(50);
		three.setMinHeight(50);
		Button four = new Button("4");
		four.setMinWidth(50);
		four.setMinHeight(50);
		Button five = new Button("5");
		five.setMinWidth(50);
		five.setMinHeight(50);
		Button six = new Button("6");
		six.setMinWidth(50);
		six.setMinHeight(50);
		Button seven = new Button("7");
		seven.setMinWidth(50);
		seven.setMinHeight(50);
		Button eight = new Button("8");
		eight.setMinWidth(50);
		eight.setMinHeight(50);
		Button nine = new Button("9");
		nine.setMinWidth(50);
		nine.setMinHeight(50);
		Button add = new Button("+");
		add.setMinWidth(50);
		add.setMinHeight(50);
		Button sub = new Button("-");
		sub.setMinWidth(50);
		sub.setMinHeight(50);
		Button mult = new Button("x");
		mult.setMinWidth(50);
		mult.setMinHeight(50);
		Button div = new Button("÷");
		div.setMinWidth(50);
		div.setMinHeight(50);
		Button equal = new Button("=");
		equal.setMinWidth(100);
		equal.setMinHeight(50);
		Button negative = new Button("+→-");
		negative.setMinWidth(50);
		negative.setMinHeight(50);
		Button clear = new Button("AC");
		clear.setMinWidth(50);
		clear.setMinHeight(50);
		Button percent = new Button("%");
		percent.setMinWidth(50);
		percent.setMinHeight(50);
		Button sqrt = new Button("√");
		sqrt.setMinWidth(50);
		sqrt.setMinHeight(50);
		Button cbrt = new Button("∛");
		cbrt.setMinWidth(50);
		cbrt.setMinHeight(50);
		Button sine = new Button("sin");
		sine.setMinWidth(50);
		sine.setMinHeight(50);
		Button cosine = new Button("cos");
		cosine.setMinWidth(50);
		cosine.setMinHeight(50);
		Button tangent = new Button("tan");
		tangent.setMinWidth(50);
		tangent.setMinHeight(50);
		
		// Create the GridPane.
		GridPane pane = new GridPane();
		
		myLabel.setFont(Font.font("Courier",FontWeight.BOLD,FontPosture.REGULAR,20));
		myLabel.setStyle("-fx-border-color: blue;");
		myLabel.setAlignment(Pos.BASELINE_RIGHT); // align text to the right side of the label.
		myLabel.setPrefSize(250, 20); // set the width and height of the label
		pane.add(myLabel,0,0,250,1);
		
		// all of the event handlers
		
		add.setOnAction(e -> {
			beginCalc("+");
		});
		
		sub.setOnAction(e -> {
			beginCalc("-");
		});
		
		mult.setOnAction(e -> {
			beginCalc("*");
		});
		
		div.setOnAction(e -> {
			beginCalc("/");
		});
		
		equal.setOnAction(e -> {
			// performing the calculations
			
			firstNumDouble = Double.parseDouble(firstNumber);
			if (!currNumber.equals("")) {
				secondNumDouble = Integer.parseInt(currNumber);
			}
			
			switch (operator) {
				case "+":
					answer = firstNumDouble + secondNumDouble;
					myLabel.setText(String.valueOf(answer));
					break;
				case "-":
					answer = firstNumDouble - secondNumDouble;
					myLabel.setText(String.valueOf(answer));
					break;
				case "*":
					answer = firstNumDouble * secondNumDouble;
					myLabel.setText(String.valueOf(answer));
					break;
				case "/":
					answer = firstNumDouble / secondNumDouble;
					myLabel.setText(String.valueOf(answer));
					break;
				case "√":
					answer = Math.sqrt(firstNumDouble);
					myLabel.setText(String.valueOf(answer));
					break;
				case "∛":
					answer = Math.cbrt(firstNumDouble);
					myLabel.setText(String.valueOf(answer));
					break;
				case "sin":
					answer = Math.sin(firstNumDouble);
					myLabel.setText(String.valueOf(answer));
					break;
				case "cos":
					answer = Math.cos(firstNumDouble);
					myLabel.setText(String.valueOf(answer));
					break;
				case "tan":
					answer = Math.tan(firstNumDouble);
					myLabel.setText(String.valueOf(answer));
					break;
			}
				
		});
		
		clear.setOnAction(e -> {
			currNumber = "";
			myLabel.setText("");
		});
		
		zero.setOnAction(e -> {
			addDigit("0");
		});
		
		one.setOnAction(e -> {
			addDigit("1");
		});
		
		two.setOnAction(e -> {
			addDigit("2");
		});
		
		three.setOnAction(e -> {
			addDigit("3");
		});
		
		four.setOnAction(e -> {
			addDigit("4");
		});
		
		five.setOnAction(e -> {
			addDigit("5");
		});
		
		six.setOnAction(e -> {
			addDigit("6");
		});
		
		seven.setOnAction(e -> {
			addDigit("7");
		});
		
		eight.setOnAction(e -> {
			addDigit("8");
		});
		
		nine.setOnAction(e -> {
			addDigit("9");
		});
		
		sqrt.setOnAction(e -> {
			firstNumber = currNumber;
			beginCalc("√");
		});
		
		cbrt.setOnAction(e -> {
			firstNumber = currNumber;
			beginCalc("∛");
		});
		
		negative.setOnAction(e -> {
			addDigit("-");
		});
		
		sine.setOnAction(e -> {
			beginCalc("sin");
		});
		
		cosine.setOnAction(e -> {
			beginCalc("cos");
		});
		
		tangent.setOnAction(e -> {
			beginCalc("tan");
		});
		
		
		pane.add(clear, 0,1,1,1);
		pane.add(negative,1,1,1,1);
		pane.add(percent,2,1,1,1);
		pane.add(div,3,1,1,1);
		pane.add(seven,0,2,1,1);
		pane.add(eight,1,2,1,1);
		pane.add(nine,2,2,1,1);
		pane.add(mult,3,2,1,1);
		pane.add(four,0,3,1,1);
		pane.add(five,1,3,1,1);
		pane.add(six,2,3,1,1);
		pane.add(sub,3,3,1,1);
		pane.add(one,0,4,1,1);
		pane.add(two,1,4,1,1);
		pane.add(three,2,4,1,1);
		pane.add(add,3,4,1,1);
		pane.add(zero,0,5,120,1);
		pane.add(equal,2,5,120,1);
		pane.add(sqrt,4,1,1,1);
		pane.add(cbrt,4,2,1,1);
		pane.add(sine,4,3,1,1);
		pane.add(cosine,4,4,1,1);
		pane.add(tangent,4,5,1,1);

		
		Scene scene = new Scene(pane,280,300);
		primaryStage.setTitle("MyJavaFX"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}
	
	public void beginCalc(String operator) {
		// set the operator and first number
		this.operator = operator;
		firstNumber = currNumber;
		currNumber = "";
	}
	
	public void updateTextField() {
		myLabel.setText(currNumber);
	}
	
	public void addDigit(String number) {
		// add a digit to the current number
		currNumber += number;
		updateTextField();
	}
	

	public static void main(String[] args)
	{
		launch(args);
	}
}